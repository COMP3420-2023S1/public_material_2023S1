#!/usr/bin/env python
import sqlite3
import pandas
import numpy
from sklearn.feature_extraction.text import TfidfVectorizer
import sklearn.linear_model
db = sqlite3.connect('enron.sqlite')
emails_df = pandas.read_sql('select * from enron', db)

from sklearn.model_selection import train_test_split
train, test = train_test_split(emails_df, random_state=1234)
tfidf = TfidfVectorizer(ngram_range=(1,2), stop_words='english')
train_vectors = tfidf.fit_transform(train.email_text)
test_vectors = tfidf.transform(test.email_text)

lr = sklearn.linear_model.LogisticRegressionCV(
    penalty='l1',
    solver='liblinear',
    # Try values increasing roughly exponentially
    # (3 is roughly half-way to ten exponentially
    # because 3^2 is approximately 10)
    Cs = [1E+1, 3E+1, 1E+2, 3E+2, 1E+3, 3E+3,
          1E+4, 3E+4, 1E+5, 3E+5, 1E+6],
    random_state=2345,
    scoring='f1_weighted'
)
lr.fit(train_vectors, train.spam_or_ham)
predictions = lr.predict(test_vectors)
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
print(confusion_matrix(predictions, test.spam_or_ham))
print(classification_report(predictions, test.spam_or_ham))

factors = pandas.Series(index=tfidf.get_feature_names_out(),
                        data=lr.coef_[0])
factors = factors[factors != 0]
print(f"Regularisation weight: {lr.C_[0]}")
print(f"Number of phrases being used for prediction: {factors.shape[0]}")
print(f"Words / phrases that predict {lr.classes_[1]}")
print(factors.nlargest(5))
print(f"Words / phrases that predict {lr.classes_[0]}")
print(factors.nsmallest(5))
