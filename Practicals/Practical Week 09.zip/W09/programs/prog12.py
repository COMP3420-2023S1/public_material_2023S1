#!/usr/bin/env python
import sqlite3
import pandas
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
import sklearn.linear_model
from sklearn.metrics import make_scorer
from sklearn.metrics import recall_score, precision_score
from sklearn.model_selection import cross_validate
from sklearn.pipeline import Pipeline

db = sqlite3.connect('enron.sqlite')
emails_df = pandas.read_sql('select * from enron', db)

train, test = train_test_split(emails_df)
tfidf = TfidfVectorizer(ngram_range=(1,2), stop_words='english')
lr = sklearn.linear_model.LogisticRegressionCV(
    penalty='l1',
    solver='liblinear',
    Cs = [3E+4, 1E+5, 3E+5, 1E+6],
    scoring='f1_weighted')

pipeline = Pipeline([
    ('tfidf', tfidf),
    ('lr', lr)
])


recall_scorer = make_scorer(recall_score, pos_label='spam')
precision_scorer = make_scorer(precision_score, pos_label='spam')
scoring = {'recall': recall_scorer,
           'precision': precision_scorer,
           'accuracy': 'accuracy'}
cv_results = cross_validate(pipeline,
                            emails_df.email_text,
                            emails_df.spam_or_ham,
                            scoring=scoring)
avg_recall = cv_results['test_recall'].mean()
avg_precision = cv_results['test_precision'].mean()
avg_accuracy = cv_results['test_accuracy'].mean()
print(f"Average Recall: {avg_recall:.2f}")
print(f"Average Precision: {avg_precision:.2f}")
print(f"Average Accuracy: {avg_accuracy:.2f}")
