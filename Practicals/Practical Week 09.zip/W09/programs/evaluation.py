#!/usr/bin/env python
import sqlite3
import pandas
from sklearn.feature_extraction.text import TfidfVectorizer
import sklearn.linear_model
db = sqlite3.connect('enron.sqlite')
emails_df = pandas.read_sql('select * from enron', db)

from sklearn.model_selection import train_test_split
train, test = train_test_split(emails_df)
tfidf = TfidfVectorizer(ngram_range=(1,2))
train_vectors = tfidf.fit_transform(train.email_text)
test_vectors = tfidf.transform(test.email_text)

lr = sklearn.linear_model.LogisticRegression(C=1000000000)
lr.fit(train_vectors, train.spam_or_ham)
predictions = lr.predict(test_vectors)
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
print(confusion_matrix(predictions, test.spam_or_ham))
print(classification_report(predictions, test.spam_or_ham))

