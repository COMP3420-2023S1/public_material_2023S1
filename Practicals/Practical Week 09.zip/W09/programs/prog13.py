#!/usr/bin/env python

import zipfile
import pandas as pd
import io
import sqlite3
import re

def read_file_from_zip(zf, file_path):
    f = zf.open(file_path, 'r')
    try:
        return io.TextIOWrapper(f, encoding='cp1252').read()
    except UnicodeDecodeError:
        pass
    f = zf.open(file_path, 'r')
    try:
        return io.TextIOWrapper(f, encoding='utf-8').read()
    except UnicodeDecodeError:
        pass
    f = zf.open(file_path, 'r')
    return io.TextIOWrapper(
        f,
        encoding='ascii',
        errors='backslashreplace').read()

def extract_email_info(email_text):
    subject_line = re.search(r'Subject: (.+)\n', email_text)
    subject = subject_line.group(1).strip() if subject_line else ''
    try:
        first_line, remaining_lines = email_text.split('\n', 2)[1:]
        return subject, remaining_lines
    except ValueError:
        return subject, email_text

zip_file = 'enron1.zip'
data = []
    
with zipfile.ZipFile(zip_file, 'r') as zf:
    for file_info in zf.infolist():
        fname = file_info.filename
        if not fname.endswith('.txt'): continue
        if fname.endswith('Summary.txt'): continue
        content = read_file_from_zip(zf, fname)
        label = 'ham' if fname.startswith('enron1/ham/') else 'spam'
        subject, body = extract_email_info(content)
        data.append({'subject': subject, 'email_body': body, 'spam_or_ham': label})

emails_df = pd.DataFrame(data)
print(emails_df.sample(5))
db = sqlite3.connect('enron-wide.sqlite')
emails_df.to_sql('enron',
                 db,
                 index=False,
                 if_exists='replace')
