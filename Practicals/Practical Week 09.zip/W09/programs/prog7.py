#!/usr/bin/env python
import sqlite3
import pandas
import numpy
from sklearn.feature_extraction.text import TfidfVectorizer
import sklearn.linear_model
db = sqlite3.connect('enron.sqlite')
emails_df = pandas.read_sql('select * from enron', db)

from sklearn.model_selection import train_test_split
train, test = train_test_split(emails_df, random_state=1234)
tfidf = TfidfVectorizer(ngram_range=(1,2))
train_vectors = tfidf.fit_transform(train.email_text)
test_vectors = tfidf.transform(test.email_text)

lr = sklearn.linear_model.LogisticRegression()
lr.fit(train_vectors, train.spam_or_ham)
predictions = lr.predict(test_vectors)
mistakes = predictions != test.spam_or_ham
for idx in mistakes.index:
    mistake = test.loc[idx]
    print(f"INCORRECTLY PREDICTED: SHOULD BE {mistake.spam_or_ham}")
    print(mistake.email_text)
    mistake_vectors = tfidf.transform([mistake.email_text])
    effects = []
    for multiplier, phrase_weight, phrase in zip(
            lr.coef_[0],
            mistake_vectors[0].toarray()[0],
            tfidf.get_feature_names_out()):
        if phrase_weight != 0:
            effects.append({'phrase': phrase,
                 'effect': multiplier * phrase_weight})
    explain_df = pandas.DataFrame.from_records(effects)
    print("Top 10 features predicting spam:")
    print(explain_df.nlargest(10, 'effect'))
    print("Top 10 features predicting ham:")    
    print(explain_df.nsmallest(10, 'effect'))
    print("\n-----------------\n")


