#!/usr/bin/env python

import sqlite3
import pandas
from sklearn.compose import ColumnTransformer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegressionCV
from sklearn.pipeline import Pipeline
from sklearn.model_selection import cross_validate
from sklearn.metrics import make_scorer, recall_score, precision_score, accuracy_score

db = sqlite3.connect('enron-wide.sqlite')
emails_df = pandas.read_sql('select * from enron', db)

subject_tfidf = TfidfVectorizer(ngram_range=(1,2), stop_words='english')
body_tfidf = TfidfVectorizer(ngram_range=(1,2), stop_words='english')
lr = LogisticRegressionCV(
    penalty='l1',
    solver='liblinear',
    Cs = [1E+4, 3E+4, 1E+5, 3E+5, 1E+6],
    scoring='f1_weighted')

preprocessor = ColumnTransformer(
    transformers=[
        ('subject', subject_tfidf, 'subject'),
        ('body', body_tfidf, 'email_body')
    ],
    remainder='drop')

pipeline = Pipeline([
    ('preprocessor', preprocessor),
    ('lr', lr)
])

recall_scorer = make_scorer(recall_score, pos_label='spam')
precision_scorer = make_scorer(precision_score, pos_label='spam')

scoring = {'recall': recall_scorer,
           'precision': precision_scorer,
           'accuracy': 'accuracy'}
cv_results = cross_validate(pipeline,
                            emails_df,
                            emails_df.spam_or_ham,
                            cv=5,
                            scoring=scoring)

avg_recall = cv_results['test_recall'].mean()
avg_precision = cv_results['test_precision'].mean()
avg_accuracy = cv_results['test_accuracy'].mean()

print(f"Average Recall: {avg_recall:.2f}")
print(f"Average Precision: {avg_precision:.2f}")
print(f"Average Accuracy: {avg_accuracy:.2f}")

pipeline.fit(emails_df, emails_df.spam_or_ham)

vocab = []
for (name, transformer, column) in pipeline['preprocessor'].transformers_:
    if name == 'subject':
        vocab += [f'SUBJECT CONTAINS {x}' for x in transformer.get_feature_names_out()]
    if name == 'body':
        vocab += [f'BODY CONTAINS {x}' for x in transformer.get_feature_names_out()]

factors = pandas.Series(
    index=vocab,
    data=lr.coef_[0])

print(f"Words / phrases that predict {pipeline['lr'].classes_[1]}")
print(factors.nlargest(5))
print(f"Words / phrases that predict {pipeline['lr'].classes_[0]}")
print(factors.nsmallest(5))
