#!/usr/bin/env python
import sqlite3
import pandas
from sklearn.feature_extraction.text import TfidfVectorizer
import sklearn.linear_model
db = sqlite3.connect('enron.sqlite')
emails_df = pandas.read_sql('select * from enron', db)

from sklearn.model_selection import train_test_split
train, test = train_test_split(emails_df, random_state=1234)
tfidf = TfidfVectorizer(ngram_range=(1,2))
train_vectors = tfidf.fit_transform(train.email_text)
test_vectors = tfidf.transform(test.email_text)

lr = sklearn.linear_model.LogisticRegression()
lr.fit(train_vectors, train.spam_or_ham)
predictions = lr.predict(test_vectors)

from sklearn.metrics import log_loss
for actual, predicted, text in zip(
        test.spam_or_ham,
        predictions,
        test.email_text):
    # Transform expects a list of values, and we only have 1.
    # So we have to make a list out of our one value
    vectors = tfidf.transform([text])
    probabilities = lr.predict_proba(vectors)
    this_probability_result = probabilities[0]
    spam_probability = this_probability_result[1]
    error = log_loss([actual],
                     [spam_probability],
                     labels=['ham', 'spam'])
    print(f"{actual}, {predicted=}, prob={spam_probability:.2f}, log_loss={error:.2f}")
    

