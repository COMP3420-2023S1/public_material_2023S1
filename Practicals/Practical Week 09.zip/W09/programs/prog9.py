#!/usr/bin/env python
import sqlite3
import pandas
import numpy
from sklearn.feature_extraction.text import TfidfVectorizer
import sklearn.linear_model
db = sqlite3.connect('enron.sqlite')
emails_df = pandas.read_sql('select * from enron', db)

from sklearn.model_selection import train_test_split
train, test = train_test_split(emails_df, random_state=1234)
tfidf = TfidfVectorizer(ngram_range=(1,2), stop_words='english')
train_vectors = tfidf.fit_transform(train.email_text)
test_vectors = tfidf.transform(test.email_text)

lr = sklearn.linear_model.LogisticRegression(
    penalty='l1',
    solver='liblinear',
    C=1E+5
)
lr.fit(train_vectors, train.spam_or_ham)
factors = pandas.Series(index=tfidf.get_feature_names_out(),
                        data=lr.coef_[0])
factors = factors[factors != 0]
print(f"Number of phrases being used for prediction: {factors.shape[0]}")
predictions = lr.predict(test_vectors)
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
print(confusion_matrix(predictions, test.spam_or_ham))
print(classification_report(predictions, test.spam_or_ham))

print(f"Words / phrases that predict {lr.classes_[1]}")
print(factors.nlargest(5))
print(f"Words / phrases that predict {lr.classes_[0]}")
print(factors.nsmallest(5))
