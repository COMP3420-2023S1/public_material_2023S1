#!/usr/bin/env python
import sqlite3
import pandas
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
import sklearn.linear_model
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.pipeline import Pipeline

db = sqlite3.connect('enron.sqlite')
emails_df = pandas.read_sql('select * from enron', db)

train, test = train_test_split(emails_df)
tfidf = TfidfVectorizer(ngram_range=(1,2), stop_words='english')
lr = sklearn.linear_model.LogisticRegressionCV(
    penalty='l1',
    solver='liblinear',
    Cs = [1E+1, 3E+1, 1E+2, 3E+2, 1E+3, 3E+3,
          1E+4, 3E+4, 1E+5, 3E+5, 1E+6],
    scoring='f1_weighted')

pipeline = Pipeline([
    ('tfidf', tfidf),
    ('lr', lr)
])

pipeline.fit(train.email_text, train.spam_or_ham)
predictions = pipeline.predict(test.email_text)

print(confusion_matrix(predictions, test.spam_or_ham))
print(classification_report(predictions, test.spam_or_ham))

factors = pandas.Series(
    index=pipeline['tfidf'].get_feature_names_out(),
    data=pipeline['lr'].coef_[0])
factors = factors[factors != 0]
print(f"Number of phrases being used for prediction: {factors.shape[0]}")
print(f"Words / phrases that predict {pipeline['lr'].classes_[1]}")
print(factors.nlargest(5))
print(f"Words / phrases that predict {pipeline['lr'].classes_[0]}")
print(factors.nsmallest(5))
