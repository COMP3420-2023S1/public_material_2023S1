#!/usr/bin/env python3

import argparse

parser = argparse.ArgumentParser()
parser.add_argument("--input",
                    required=True
                    help="Filename to read from")
parser.add_argument("--output",
                    required=True,
                    help="Filename to write")
args = parser.parse_args()

with open(args.input) as f:
    f.read()
