#!/usr/bin/env python3
import nltk
import math
emma = nltk.corpus.gutenberg.words('austen-emma.txt')
vocab_so_far = set()
vocab_sizes = []
word_counts = []
log_word_counts = []
log_vocab_sizes = []
for i,w in enumerate(emma):
    vocab_so_far.update([w])
    vocab_sizes.append(len(vocab_so_far))
    word_counts.append(i+1)
    log_word_counts.append(math.log10(i+1))
    log_vocab_sizes.append(math.log10(len(vocab_so_far)))

import pandas
import numpy
herdans_data = pandas.Series(data=vocab_sizes, index=word_counts)
log_data = pandas.Series(data=log_vocab_sizes, index=log_word_counts)
beta, log_k = numpy.polyfit(log_word_counts, log_vocab_sizes, 1)
k = 10**log_k

# Print the values of k and beta
print("k =", k)
print("beta =", beta)

import matplotlib.pyplot
fig, axes = matplotlib.pyplot.subplots(nrows=2)
herdans_data.plot(ax=axes[0], title="Herdan's Law for Emma")
log_data.plot(ax=axes[1], title="Log-Log Plot")
fig.tight_layout()
fig.savefig('herdans.png')

