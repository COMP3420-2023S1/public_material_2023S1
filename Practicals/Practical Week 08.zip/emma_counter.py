#!/usr/bin/env python3
import nltk
import collections
import matplotlib.pyplot

emma = nltk.corpus.gutenberg.words('austen-emma.txt')
print(f"The number of words is {len(emma)=} ")
print(f"Distinct words = {len(set(emma))}")
print(f"First ten words... {emma[:10]=}")
emma_counter = collections.Counter(emma)
print(f"Top ten most fcommon words: {emma_counter.most_common(10)=}")

# Prepare the data for the plot
word_frequencies = []
for word, count in emma_counter.most_common():
    word_frequencies.append(count)
ranks = list(range(1, len(word_frequencies) + 1))

# Create a log-log plot showing word frequencies vs ranking
fig, ax = matplotlib.pyplot.subplots()
ax.loglog(ranks, word_frequencies, marker='.')
ax.set_xlabel('Rank')
ax.set_ylabel('Frequency')
ax.set_title("Zipf's Law - Emma by Jane Austen")
ax.grid(True)

# Save the figure
fig.savefig("emma_zipf.png")

# If we want to calculate the parameters...
import sklearn.linear_model
import pandas
import math
X = pandas.DataFrame({'ranks': ranks, 'frequencies': word_frequencies})
X['log_rank'] = X['ranks'].map(math.log10)
X['log_frequencies'] = X['frequencies'].map(math.log10)
lr = sklearn.linear_model.LinearRegression()
lr.fit(X[['log_rank']], X.log_frequencies)
print(f"log_frequencies = {lr.coef_[0]} * log_rank + {lr.intercept_}")

