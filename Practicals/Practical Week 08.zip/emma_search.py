#!/usr/bin/env python
import nltk
import numpy
emma_text = nltk.corpus.gutenberg.raw('austen-emma.txt')
emma_sentences = nltk.sent_tokenize(emma_text)
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
tfidf = TfidfVectorizer(stop_words='english', ngram_range=(1,2), min_df=1)
emma_sentences_as_vectors = tfidf.fit_transform(
    emma_sentences
)
print(emma_sentences_as_vectors.shape)
print(type(emma_sentences_as_vectors))
print(tfidf.get_feature_names_out()[1000:1005])
try:
    while True:
        query = input("Search for: ")
        query_as_vector = tfidf.transform([query])
        similarities = cosine_similarity(emma_sentences_as_vectors,
                                     query_as_vector)
        ranked_results = numpy.argsort(similarities, axis=0)[::-1]
        match_found = False
        for result_position in ranked_results[:3]:
            sentence_number = result_position[0]
            scoring = similarities[sentence_number]
            if scoring == 0.0: break
            match_found = True
            sentence = emma_sentences[sentence_number]
            print(sentence_number, scoring, sentence)
            if not match_found:
                print("No matches found")
except EOFError:
    break

