#!/usr/bin/env python3
import nltk
nltk.download('wordnet')
nltk.download('omw-1.4')
