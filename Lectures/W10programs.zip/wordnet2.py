#!/usr/bin/env python3

from nltk.corpus import wordnet as wn
synsets = wn.synsets('car')
print(synsets[0])
print(synsets[0].hypernyms())
x = synsets[0].hypernyms()[0]
while True:
    print(x.hypernyms())
    if len(x.hypernyms()) > 0:
        x = x.hypernyms()[0]
    else:
        break
