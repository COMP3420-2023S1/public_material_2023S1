#!/usr/bin/env python3
import pandas
from tensorflow import keras
from sklearn.model_selection import train_test_split
import numpy as np
import matplotlib.pyplot as plt
from nltk.corpus import wordnet as wn

keras.utils.set_random_seed(1234)
df = pandas.read_csv('fluff-data.csv')
df['target'] = np.where(df.Fur == 'furry',
                        1.0, 0.0)

def hypernym_line(synset):
    s = set()
    hypernyms = synset.hypernyms()
    for h in hypernyms:
        s.update([h])
        parents = hypernym_line(h)
        s.update(parents)
    return s
def enrich_with_hypernyms(x):
    synsets = wn.synsets(x)
    if len(synsets) == 0: return x
    first_synset = synsets[0]
    hypernyms = hypernym_line(first_synset)
    h = " ".join([x.lemma_names()[0] for x in hypernyms])
    return x + " " + h
df['enriched'] = df.Thing.map(enrich_with_hypernyms)

train, validation = train_test_split(df)
# Pretend we have additional training data somewhere
        
vectorizer = keras.layers.TextVectorization(output_mode='count')
vectorizer.adapt(train.enriched)
train_data = vectorizer(train.enriched)
validation_data = vectorizer(validation.enriched)

inputs = keras.Input(shape=(vectorizer.vocabulary_size(),))
output = keras.layers.Dense(1,
          activation="sigmoid")(inputs)
model = keras.Model(inputs=[inputs],outputs=[output])
model.compile(
    loss='binary_crossentropy',
    metrics=['accuracy'])

history = model.fit(x=train_data, y=train.target,
    validation_data=(
        validation_data,
        validation.target),
    verbose=2,
    epochs=1000)

fig, axes = plt.subplots(ncols=2, figsize=(12,6))
axes[0].plot(history.history['accuracy'],
        label='Training Accuracy')
axes[0].plot(history.history['val_accuracy'],
        label='Validation Accuracy')
axes[0].set_title('Training and Validation Accuracy')
axes[0].set_xlabel('Epochs')
axes[0].set_ylabel('Accuracy (bigger is better)')
axes[0].legend()


axes[1].plot(history.history['loss'],
        label='Training Loss')
axes[1].plot(history.history['val_loss'],
        label='Validation Loss')
axes[1].set_title('Training and Validation Loss')
axes[1].set_xlabel('Epochs')
axes[1].set_ylabel('Loss (smaller is better)')
axes[1].legend()

fig.savefig("fur-success.png")


vocab = vectorizer.get_vocabulary()
weights = model.get_weights()[0][:,0]
strengths = pandas.Series(index=vocab, data=weights)
strengths.nlargest(5).to_latex('fur-success-positive.tex')
strengths.nsmallest(5).to_latex('fur-success-negative.tex')
