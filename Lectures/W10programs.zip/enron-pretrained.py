#!/usr/bin/env python

import sqlite3
import pandas
from tensorflow import keras
import tensorflow as tf
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from keras.layers import Dense, TextVectorization
import matplotlib.pyplot as plt
import collections
import nltk

keras.utils.set_random_seed(123456)

db = sqlite3.connect('enron.sqlite')
emails_df = pandas.read_sql('select * from enron', db)
emails_df['spaminess'] = np.where(
    emails_df.spam_or_ham == 'spam', 1.0, 0.0)

pseudo_train_data, test_data = train_test_split(emails_df)
train_data, validation_data = train_test_split(pseudo_train_data)

sequence_length = 200
vectorizer = TextVectorization(
    output_sequence_length=sequence_length,
    output_mode='int')
vectorizer.adapt(train_data.email_text)
train_vectors = vectorizer(train_data.email_text)

validation_vectors = vectorizer(validation_data.email_text)
test_vectors = vectorizer(test_data.email_text)

embeddings_index = {}
with open('glove.6B.50d.txt') as f:
    for line in f:
        word, coefs = line.split(maxsplit=1)
        coefs = np.fromstring(coefs, "f", sep=" ")
        embeddings_index[word] = coefs

voc = vectorizer.get_vocabulary()
word_index = dict(zip(voc, range(len(voc))))
embedding_matrix = np.zeros((len(voc)+2, 50))
for word, i in word_index.items():
    embedding_vector = embeddings_index.get(word)
    if embedding_vector is not None:
        embedding_matrix[i] = embedding_vector


from keras.initializers import Constant        
embedding_layer = keras.layers.Embedding(
 input_dim=len(voc)+2,
 output_dim=50,
 embeddings_initializer=Constant(embedding_matrix),
 trainable=False)

vocab_size = vectorizer.vocabulary_size()
inputs = keras.Input(shape=(sequence_length,))
embedding = embedding_layer(inputs)
averaging_layer = keras.layers.GlobalAveragePooling1D()(embedding)
thinking_layer = keras.layers.Dense(8, activation="relu")(averaging_layer)
output = Dense(1, activation="sigmoid")(thinking_layer)
model = keras.Model(
    inputs=[inputs],
    outputs=[output])
callbacks = [keras.callbacks.EarlyStopping(
        monitor='val_loss', patience=10
    )]


model.compile(loss='binary_crossentropy',
    metrics=["accuracy"])

model.summary()
history = model.fit(
    x=train_vectors,
    y=train_data.spaminess,
    validation_data=(validation_vectors,
                     validation_data.spaminess),
    callbacks=callbacks,
    verbose=1,
    epochs=500)

fig, axes = plt.subplots(ncols=2, figsize=(12,6))
axes[0].plot(history.history['accuracy'],
        label='Training Accuracy')
axes[0].plot(history.history['val_accuracy'],
        label='Validation Accuracy')
axes[0].set_title('Training and Validation Accuracy')
axes[0].set_xlabel('Epochs')
axes[0].set_ylabel('Accuracy (bigger is better)')
axes[0].legend()


axes[1].plot(history.history['loss'],
        label='Training Loss')
axes[1].plot(history.history['val_loss'],
        label='Validation Loss')
axes[1].set_title('Training and Validation Loss')
axes[1].set_xlabel('Epochs')
axes[1].set_ylabel('Loss (smaller is better)')
axes[1].legend()

fig.savefig("enron-pretrained.png")
print("Test evaluation:")
print(model.evaluate(test_vectors,
                     test_data.spaminess,
                     return_dict=True,
                     verbose=0))
