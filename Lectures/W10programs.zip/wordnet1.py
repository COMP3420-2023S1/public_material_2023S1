#!/usr/bin/env python3

from nltk.corpus import wordnet as wn
synsets = wn.synsets('car')
print(synsets)
print(synsets[0].definition())
print(synsets[0].examples())
print(synsets[0].lemmas())
print(synsets[0].lemmas(lang='spa'))
      
