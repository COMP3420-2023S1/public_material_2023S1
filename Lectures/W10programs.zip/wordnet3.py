#!/usr/bin/env python3

from nltk.corpus import wordnet as wn
synsets = wn.synsets('car')
for car_example in synsets[0].hyponyms()[:10]:
    print(car_example)

