#!/usr/bin/env python3
import pandas
from tensorflow import keras
from sklearn.model_selection import train_test_split
import numpy as np
import matplotlib.pyplot as plt
keras.utils.set_random_seed(1234)
df = pandas.read_csv('fluff-data.csv')
df['target'] = np.where(df.Fur == 'furry',
                        1.0, 0.0)
train, validation = train_test_split(df)
# Pretend we have additional training data somewhere
vectorizer = keras.layers.StringLookup()
vectorizer.adapt(train.Thing)
train_data = vectorizer(train.Thing)
validation_data = vectorizer(validation.Thing)

inputs = keras.Input(shape=(1,))
output = keras.layers.Dense(1,
          activation="sigmoid")(inputs)
model = keras.Model(inputs=[inputs],outputs=[output])
model.compile(
    loss='binary_crossentropy',
    metrics=['accuracy'])

history = model.fit(x=train_data, y=train.target,
    validation_data=(
        validation_data,
        validation.target),
    verbose=2,
    epochs=10)

fig, axes = plt.subplots(ncols=2, figsize=(12,6))
axes[0].plot(history.history['accuracy'],
        label='Training Accuracy')
axes[0].plot(history.history['val_accuracy'],
        label='Validation Accuracy')
axes[0].set_title('Training and Validation Accuracy')
axes[0].set_xlabel('Epochs')
axes[0].set_ylabel('Accuracy (bigger is better)')
axes[0].legend()


axes[1].plot(history.history['loss'],
        label='Training Loss')
axes[1].plot(history.history['val_loss'],
        label='Validation Loss')
axes[1].set_title('Training and Validation Loss')
axes[1].set_xlabel('Epochs')
axes[1].set_ylabel('Loss (smaller is better)')
axes[1].legend()

fig.savefig("furfail.png")
