#!/usr/bin/env python3

# Based on this very fun tutorial:
#  https://cosmiccoding.com.au/tutorials/encoding_colours/

import pandas as pd
import tensorflow as tf
import matplotlib.pyplot as plt
import keras
from keras.layers import Embedding, Lambda, Dense, Flatten
import subprocess

colour_pairs = pd.read_csv('colour-pairs.txt')
colour_lookup_data = pd.read_csv('colour-lookup.txt')
colour_lookup = colour_lookup_data.set_index('colour_number').hex.to_dict()

keras.utils.set_random_seed(1234)

def euclidean_distance(tensor):
    x1, y1, x2, y2 = tensor[:, 0], tensor[:, 1], tensor[:, 2], tensor[:, 3]
    distance = (x1 - x2)**2 + (y1 - y2)**2
    return tf.expand_dims(distance, axis=-1)

inputs = keras.Input(shape=(2,))
embedding_layer = Embedding(
    input_dim=len(colour_lookup),
    output_dim=2,
    input_length=2
)(inputs)
flattening_layer = Flatten()(embedding_layer)
distance_layer = Lambda(euclidean_distance)(flattening_layer)
output = Dense(1, activation="sigmoid")(distance_layer)
model = keras.Model(inputs=[inputs], outputs=[output])
model.compile(loss='binary_crossentropy')

current_epoch = 0
def plot_weights(batch, logs):
    global current_epoch
    weights = model.layers[1].get_weights()[0]
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.scatter(x=weights[:,0], y=weights[:,1],
               c=colour_lookup.values())
    outfile = f"colour-anim/frame{current_epoch:04d}.png"
    fig.savefig(outfile)
    plt.close(fig)
    current_epoch += 1

save = keras.callbacks.LambdaCallback(on_epoch_end=plot_weights)

model.fit(colour_pairs[["colour_number_x", "colour_number_y"]],
          colour_pairs["colours_are_similar"],
          epochs=5000,
          #batch_size=512,
          callbacks=[save])

subprocess.run(["ffmpeg", "-framerate", "24",
                "-i", "colour-anim/frame%04d.png",
                "-c:v", "libx264",
                "-pix_fmt",  "yuv420p",
                "colour-animation.mp4"])
