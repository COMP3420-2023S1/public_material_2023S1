#!/usr/bin/env python3

import openai

#!/usr/bin/env python3

import argparse
import json
import os
import sys

import openai
openai.api_key = open(os.path.expanduser('~/.openai.key')).read().strip()

parser = argparse.ArgumentParser()
parser.add_argument("--model", default="gpt-3.5-turbo",
                    choices=["gpt-3.5-turbo", "gpt-4"],
                    help="Which GPT model to use")
parser.add_argument("--temperature", default=None, type=float,
                    help="Temperature for word selection")
parser.add_argument("--system", help="System prompt")
parser.add_argument("--prompt", nargs="+", required=True,
                    help="User prompts")
parser.add_argument("--verbose", action="store_true", help="Report on more than just the raw response")
args = parser.parse_args()

if args.system is None:
    system_messages = []
else:
    content = open(args.system).read()
    system_messages = [{"role": "system", "content": content}]

if args.temperature is None:
    # if you want consistency
    #temperature = 0.0
    # if you want similar to the web interface
    temperature = 1.0
else:
    temperature = args.temperature
    
response = openai.ChatCompletion.create(
    model=args.model,
    temperature=temperature,
    messages = system_messages + [
        {"role": "user", "content": open(x).read()} for x in args.prompt
    ],
    user='greg.baker@mq.edu.au'
)

reply_text = response['choices'][0]['message']['content']
prompt_tokens = response['usage']['prompt_tokens']
completion_tokens = response['usage']['completion_tokens']
total_tokens = response['usage']['total_tokens']
finish_reason = response['choices'][0]['finish_reason']

print(reply_text)
if args.verbose:
    print("{prompt_tokens=}")
    print("{completion_tokens=}")
    print("{total_tokens=}")
    print("{finish_reason=}")
if finish_reason != 'stop':
    sys.exit(1)
