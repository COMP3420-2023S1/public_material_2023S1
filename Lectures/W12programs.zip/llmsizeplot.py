#!/usr/bin/env python3

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.linear_model import LinearRegression
import math

# Read CSV file
df = pd.read_csv('llmsize.csv')

# Convert parameter count to numerical format and apply log transformation
df['Parameters (Millions)'] = df['Parameters (Millions)'].str.replace(',', '').astype(float)
df['Log Parameters'] = np.log10(df['Parameters (Millions)'])

# Scatter plot
plt.scatter(df['Year'], df['Parameters (Millions)'])
plt.yscale('log')

# Linear regression model for trendline
X = df['Year'].values.reshape(-1, 1)
y = df['Log Parameters'].values.reshape(-1, 1)
model = LinearRegression()
model.fit(X, y)

# Project trendline out to 2025
X_future = np.array(range(2009, 2031)).reshape(-1, 1)
y_future = model.predict(X_future)

doubling_time = math.log10(2) / model.coef_[0][0]
print(f"Parameter size doubles every {12*doubling_time:.2f} months")
with open('llmsize-double-in-months.txt', 'w') as f:
    f.write(f"{12*doubling_time:.2f}\n")
factor_of_ten = math.log10(10) / model.coef_[0][0]
print(f"Parameter size grows by a factor of 10 every {factor_of_ten:.2f} years")
with open('llmsize-factor10-in-years.txt', 'w') as f:
    f.write(f"{factor_of_ten:.2f}\n")
    
# Approximate human
plt.axhline(1000000000, color="purple")
plt.annotate("Number of synapses in a human brain (1 quadrillion)",
             (2010, 500000000), xytext=(-15,-10),
             textcoords='offset points', fontsize=10,
             c="purple")


# Plot trendline
plt.plot(X_future, 10**y_future, color='red')

for i, row in df.iterrows():
    plt.annotate(row['Model'], (row['Year'], row['Parameters (Millions)']), xytext=(-15,-10), textcoords='offset points', fontsize=8)

# Adjusting the plot
plt.title('Language Model Size Over Time')
plt.xlabel('Year')
plt.ylabel('Parameters (Millions, Log Scale)')
plt.grid(True)

# Save figure
plt.savefig('llmsize-chart.png')
